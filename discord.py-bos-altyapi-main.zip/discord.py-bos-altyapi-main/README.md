**configuration.json dosyasını doldurun!**
---------
Hata alırsanız Discord: **Ponche#6600**
